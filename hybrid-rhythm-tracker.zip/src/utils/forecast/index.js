import calculateRunningTotals from "./runningTotals";
import projectWeeks from "./projectWeeks";
import recoverTarget from "./recoverTarget";
import buildDashboard from "./buildDashboard";
import generateFutureWeeks from "./generateFutureWeeks";

export function forecast(rawWeeks) {
  const allWeeks = generateFutureWeeks(rawWeeks);

  const totals = calculateRunningTotals(allWeeks);

  const projected = projectWeeks(totals);

  const recovered = recoverTarget(projected);

  // Temp
  const future = generateFutureWeeks(rawWeeks);
  console.log("future", future.length);

  console.log("projected", projected.length);

  console.log("recovered", recovered.length);
  // Temp

  return buildDashboard(recovered);
}
