import { supabase } from "../lib/supabaseClient";

export async function getCalendarEvents() {
  const { data, error } = await supabase
    .from("calendar_events")
    .select("*")
    .order("event_date");

  if (error) throw error;

  return data;
}

export async function createCalendarEvent(event) {
  const { error } = await supabase.from("calendar_events").insert(event);

  if (error) throw error;
}

export async function updateCalendarEvent(id, updates) {
  const { error } = await supabase
    .from("calendar_events")
    .update(updates)
    .eq("id", id);

  if (error) throw error;
}

export async function deleteCalendarEvent(id) {
  const { error } = await supabase
    .from("calendar_events")
    .delete()
    .eq("id", id);

  if (error) throw error;
}
