import WorkCalendar from "../components/WorkCalendar/WorkCalendar";

export default function WorkCalendarPage({ calendarEvents }) {
  return (
    <div className="min-h-screen bg-slate-900 text-white p-6">
      <h1 className="text-3xl font-bold">Work Calendar</h1>

      <p className="text-slate-400 mt-2">
        Configure Holidays, Leave and Work From Home days.
      </p>

      <div className="mt-8">
        <WorkCalendar events={calendarEvents} />
      </div>
    </div>
  );
}
