import { useMemo, useState } from "react";
import { DayPicker } from "react-day-picker";
import "react-day-picker/dist/style.css";

export default function WorkCalendar({ events = [] }) {
  const [selected, setSelected] = useState();

  const modifiers = useMemo(() => {
    return {
      holiday: events
        .filter((e) => e.event_type === "HOLIDAY")
        .map((e) => new Date(e.event_date)),

      leave: events
        .filter((e) => e.event_type === "LEAVE")
        .map((e) => new Date(e.event_date)),

      wfh: events
        .filter((e) => e.event_type === "WFH")
        .map((e) => new Date(e.event_date)),
    };
  }, [events]);

  return (
    <div className="rounded-xl bg-slate-800 p-6">
      <DayPicker
        classNames={{
          months: "text-white",
          month: "space-y-4",
          caption: "flex justify-center text-lg font-bold text-white",
          head_row: "flex",
          head_cell: "w-10 text-slate-400 text-sm",
          row: "flex mt-2",
          cell: "w-10 h-10 flex items-center justify-center",
          day: "w-10 h-10 rounded-lg hover:bg-slate-700 transition",
          selected: "bg-emerald-500 text-slate-900",
          today: "border border-emerald-400",
        }}
        modifiersClassNames={{
          holiday: "bg-red-500 text-white rounded-lg",
          leave: "bg-amber-500 text-slate-900 rounded-lg",
          wfh: "bg-blue-500 text-white rounded-lg",
        }}
        mode="single"
        selected={selected}
        onSelect={setSelected}
        showOutsideDays
        modifiers={modifiers}
      />
    </div>
  );
}
